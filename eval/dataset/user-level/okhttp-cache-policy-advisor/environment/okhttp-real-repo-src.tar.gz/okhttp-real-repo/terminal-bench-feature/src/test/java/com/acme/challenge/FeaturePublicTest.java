package com.acme.challenge;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FeaturePublicTest {
    @Test
    void publicExampleMatchesSpecification() {
        String input = "{\"request\":{\"headers\":{},\"method\":\"GET\"},\"response\":{\"headers\":{\"Cache-Control\":\"max-age=60\"},\"status\":200}}";
        String expected = "{\"cacheable\":true,\"freshnessSeconds\":60,\"reasons\":[\"explicit max-age\"]}";
        assertEquals(expected, new FeatureService().evaluate(input));
    }
}
