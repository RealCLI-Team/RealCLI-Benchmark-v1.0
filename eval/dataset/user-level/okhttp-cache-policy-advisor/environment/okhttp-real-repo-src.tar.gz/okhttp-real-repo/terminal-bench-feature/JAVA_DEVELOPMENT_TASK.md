# OkHttp cache policy advisor

Clone OkHttp and add a feature module that explains whether HTTP responses are cacheable under request/response metadata.


This task uses a pinned real repository clone.

- Repository: `https://github.com/square/okhttp.git`
- Ref: `refs/tags/parent-4.12.0`
- Verified ref hash: `f4ff8e57892a044840b1dbb279c840ffdba37b30`
- Feature module: `/app/okhttp-real-repo/terminal-bench-feature`

Keep the cloned repository available. Implement the requested feature inside the
`terminal-bench-feature` module, using the real repository context where useful.

## Required interface

Implement:

```java
com.acme.challenge.FeatureService#evaluate(String requestJson)
```

and keep the CLI working:

```text
com.acme.challenge.FeatureCli --input <json path> --output <json path>
```

The CLI must read the full input JSON file, invoke `FeatureService`, and write a
parseable JSON output file. The tests compare JSON objects, not formatting.

## Requirements

1. Evaluate HTTP method, status code, Cache-Control, Expires, Authorization, and Vary headers.
2. Return cacheable, freshnessSeconds, and ordered reasons.
3. Honor no-store and private directives over freshness directives.
4. Handle missing or malformed date headers without throwing.

## Evaluation model

The verifier is not binary. It writes:

- `/logs/verifier/score.json` with per-capability weighted scores.
- `/logs/verifier/reward.txt` with the overall fractional score.

Capability boundaries are defined in `tests/test_manifest.json`.
