package com.acme.challenge;

import java.nio.file.Files;
import java.nio.file.Path;

public class FeatureCli {
    public static void main(String[] args) throws Exception {
        Path input = null;
        Path output = null;
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if ("--input".equals(arg) && i + 1 < args.length) {
                input = Path.of(args[++i]);
            } else if ("--output".equals(arg) && i + 1 < args.length) {
                output = Path.of(args[++i]);
            } else {
                throw new IllegalArgumentException("Unknown or incomplete argument: " + arg);
            }
        }
        if (input == null || output == null) {
            throw new IllegalArgumentException("Usage: --input <json> --output <json>");
        }
        String result = new FeatureService().evaluate(Files.readString(input));
        if (output.getParent() != null) {
            Files.createDirectories(output.getParent());
        }
        Files.writeString(output, result);
    }
}
