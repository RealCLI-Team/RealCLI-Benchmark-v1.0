package com.acme.challenge;

public class FeatureService {
    public String evaluate(String requestJson) {
        return "{\"status\":\"not_implemented\"}";
    }
}
