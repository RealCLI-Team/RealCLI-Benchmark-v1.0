package com.acme.challenge;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FeaturePublicTest {
    @Test
    void publicExampleMatchesSpecification() {
        String input = "{\"channel\":\"email\",\"data\":{\"name\":\"Ada <L>\",\"total\":\"$7\"},\"locale\":\"en-US\",\"templates\":{\"en\":\"Hi {{name}}, total {{total|0}}\"}}";
        String expected = "{\"fallbackLocale\":\"en\",\"missing\":[],\"rendered\":\"Hi Ada &lt;L&gt;, total $7\"}";
        assertEquals(expected, new FeatureService().evaluate(input));
    }
}
