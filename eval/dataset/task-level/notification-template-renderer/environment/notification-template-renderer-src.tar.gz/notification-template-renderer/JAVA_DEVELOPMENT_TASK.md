# Notification template renderer

Implement template rendering with defaults, escaping, missing-variable diagnostics, and locale fallback.


This is a synthetic Java feature-development task. The setup script creates a
small Maven project at `/app/notification-template-renderer` with a deliberately incomplete
implementation.

## Required interface

Implement:

```java
com.acme.challenge.FeatureService#evaluate(String requestJson)
```

and keep the CLI working:

```text
com.acme.challenge.FeatureCli --input <json path> --output <json path>
```

The CLI must read the full input JSON file, invoke `FeatureService`, and write a
parseable JSON output file. The tests compare JSON objects, not formatting.

## Requirements

1. Render {{name}} variables from a data object and support {{name|default}} defaults.
2. Resolve template text by locale with fallback to the default locale.
3. HTML-escape substituted values when channel is email, but not when channel is sms.
4. Return rendered text plus sorted missing variable names and fallback diagnostics.

## Evaluation model

The verifier is not binary. It writes:

- `/logs/verifier/score.json` with per-capability weighted scores.
- `/logs/verifier/reward.txt` with the overall fractional score.

Capability boundaries are defined in `tests/test_manifest.json`.
